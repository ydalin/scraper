# trade.py – FINAL: TP/SL WITH positionSide + NO PARAMS ERROR
import asyncio
from api import bingx_api_request

def print_payload(title, data):
    print(f"\n{title} PAYLOAD TO BINGX:")
    for k, v in data.items():
        print(f"  {k}: {v}")
    print("-" * 50)

async def get_order_status(client, symbol, order_id):
    """Get order status from BingX"""
    try:
        resp = await bingx_api_request(
            'GET', '/openApi/swap/v2/trade/queryOrder',
            client['api_key'], client['secret_key'], client['base_url'],
            params={
                'symbol': symbol,
                'orderId': order_id
            }
        )
        if resp.get('code') == 0:
            order_data = resp.get('data', {})
            return order_data.get('status')  # FILLED, NEW, CANCELED, etc.
        return None
    except Exception as e:
        print(f"[ORDER STATUS ERROR] {e}")
        return None

async def cancel_order(client, symbol, order_id):
    """Cancel an order on BingX"""
    try:
        resp = await bingx_api_request(
            'DELETE', '/openApi/swap/v2/trade/order',
            client['api_key'], client['secret_key'], client['base_url'],
            data={
                'symbol': symbol,
                'orderId': order_id
            }
        )
        if resp.get('code') == 0:
            return True
        else:
            print(f"[CANCEL ORDER ERROR] {resp.get('msg')}")
            return False
    except Exception as e:
        print(f"[CANCEL ORDER ERROR] {e}")
        return False

async def get_position_size(client, symbol, position_side):
    """Get current position size for a specific position side"""
    try:
        resp = await bingx_api_request(
            'GET', '/openApi/swap/v2/trade/position',
            client['api_key'], client['secret_key'], client['base_url'],
            params={'symbol': symbol}
        )
        if resp.get('code') == 0 and resp.get('data'):
            position_data = resp['data']
            # Check if data is a list or dict
            if isinstance(position_data, list):
                for pos in position_data:
                    if pos.get('positionSide') == position_side:
                        return abs(float(pos.get('positionAmt', 0)))
            elif isinstance(position_data, dict):
                if position_data.get('positionSide') == position_side:
                    return abs(float(position_data.get('positionAmt', 0)))
        return 0.0
    except Exception as e:
        print(f"[POSITION SIZE ERROR] {e}")
        return 0.0

async def monitor_tp_and_trail_sl(client, symbol, position_side, entry, qty, tp_orders, sl_id, trail_tp_level, config):
    """Monitor TP orders and move SL to breakeven when target TP is hit"""
    if trail_tp_level == 0 or trail_tp_level > len(tp_orders):
        return
    
    print(f"\n[TP MONITOR] Starting monitoring for TP{trail_tp_level} fill...")
    target_tp = None
    for tp_order in tp_orders:
        if tp_order['tp_level'] == trail_tp_level:
            target_tp = tp_order
            break
    
    if not target_tp:
        print(f"[TP MONITOR] TP{trail_tp_level} not found in TP orders list")
        return
    
    check_interval = 5  # Check every 5 seconds
    max_checks = 3600  # Monitor for up to 5 hours (3600 * 5s = 5h)
    checks = 0
    
    while checks < max_checks:
        await asyncio.sleep(check_interval)
        checks += 1
        
        # First, check if position still exists
        position_size = await get_position_size(client, symbol, position_side)
        if position_size == 0:
            print(f"\n[TP MONITOR] Position closed. Stopping monitoring.")
            break
        
        # Check if target TP order is filled
        status = await get_order_status(client, symbol, target_tp['order_id'])
        
        if status == 'FILLED':
            print(f"\n✅ [TP MONITOR] TP{trail_tp_level} FILLED! Moving SL to breakeven...")
            
            # Cancel old SL order
            if sl_id:
                print(f"[TP MONITOR] Canceling old SL order {sl_id}...")
                cancel_success = await cancel_order(client, symbol, sl_id)
                if cancel_success:
                    print(f"✓ Old SL order canceled")
                else:
                    print(f"⚠️  Failed to cancel old SL order (may already be filled/canceled)")
            
            # Wait a moment for cancellation to process
            await asyncio.sleep(1)
            
            # Get actual remaining position size from exchange
            remaining_qty = await get_position_size(client, symbol, position_side)
            
            if remaining_qty == 0:
                print(f"[TP MONITOR] Position fully closed. No breakeven SL needed.")
                break
            
            # Set new SL at entry (breakeven)
            opposite_side = 'SELL' if position_side == 'LONG' else 'BUY'
            new_sl_payload = {
                'symbol': symbol,
                'side': opposite_side,
                'positionSide': position_side,
                'type': 'STOP_MARKET',
                'quantity': f"{remaining_qty:.6f}",
                'stopPrice': str(entry),
                'workingType': 'MARK_PRICE'
                # Note: reduceOnly is NOT used in Hedge mode (causes error)
                # The opposite side + positionSide combination ensures it closes the position
            }
            
            print_payload(f"NEW BREAKEVEN SL (after TP{trail_tp_level})", new_sl_payload)
            
            new_sl_resp = await bingx_api_request(
                'POST', '/openApi/swap/v2/trade/order',
                client['api_key'], client['secret_key'], client['base_url'],
                data=new_sl_payload
            )
            
            if new_sl_resp.get('code') == 0:
                new_sl_id = new_sl_resp.get('data', {}).get('order', {}).get('orderId')
                print(f"✅ NEW BREAKEVEN SL SET: ID = {new_sl_id}, Price = {entry}")
                print(f"   Remaining position: {remaining_qty:.6f} ({remaining_qty/qty*100:.1f}%)")
            else:
                print(f"❌ FAILED to set breakeven SL: {new_sl_resp.get('msg')}")
            
            # Stop monitoring after moving SL
            break
        elif status == 'CANCELED':
            print(f"[TP MONITOR] TP{trail_tp_level} was canceled. Stopping monitoring.")
            break
        elif status is None:
            # Order might not exist or API error - continue monitoring
            if checks % 12 == 0:  # Log every minute
                print(f"[TP MONITOR] Still monitoring TP{trail_tp_level}... (check {checks}/{max_checks})")
    
    if checks >= max_checks:
        print(f"[TP MONITOR] Monitoring timeout reached. TP{trail_tp_level} may not have filled yet.")

async def execute_trade(client, signal, usdt_amount, dry_run, custom_leverage, config=None):
    """Execute trade with configurable parameters"""
    if config is None:
        from config import DEFAULT_CONFIG
        config = DEFAULT_CONFIG
    
    symbol = signal['symbol'].replace('/', '-')
    side = 'BUY' if signal['direction'] == 'LONG' else 'SELL'
    opposite_side = 'SELL' if signal['direction'] == 'LONG' else 'BUY'
    position_side = signal['direction']  # LONG or SHORT
    leverage = custom_leverage
    entry = signal['entry']
    qty = (usdt_amount * leverage) / entry
    
    # === CHECK FOR EXISTING POSITION ===
    if not dry_run:
        try:
            pos_resp = await bingx_api_request(
                'GET', '/openApi/swap/v2/trade/position',
                client['api_key'], client['secret_key'], client['base_url'],
                params={'symbol': symbol}
            )
            if pos_resp.get('code') == 0 and pos_resp.get('data'):
                position_data = pos_resp['data']
                # Check if data is a list or dict
                if isinstance(position_data, list):
                    position_data = position_data[0] if position_data else {}
                
                # Check if there's an existing position with the same side
                position_amt = float(position_data.get('positionAmt', 0))
                if position_amt != 0:
                    existing_side = position_data.get('positionSide', 'unknown')
                    print(f"\n⚠️  SKIPPING TRADE: Existing {existing_side} position found for {symbol}")
                    print(f"   Position Amount: {position_amt}")
                    print(f"   Cannot open duplicate position. Close existing position first.\n")
                    return
        except Exception as e:
            print(f"⚠️  Could not check existing position: {e}")
            print(f"   Proceeding with trade anyway (position check failed)")
    
    
    # Position mode: Cross or Isolated
    position_mode = config.get('position_mode', 'Cross').upper()
    # For marginType endpoint: ISOLATED or CROSSED
    margin_type = 'CROSSED' if position_mode == 'CROSS' else 'ISOLATED'
    # For openType in orders: isolated or cross (lowercase)
    open_type = 'cross' if position_mode == 'CROSS' else 'isolated'
    
    # Order type: MARKET or LIMIT
    order_type = config.get('order_type', 'MARKET').upper()
    
    # === SL VALIDATION: Ensure SL is -2% from entry ===
    direction = signal['direction']
    expected_sl = entry * (1.02 if direction == 'SHORT' else 0.98)
    sl_diff = abs((signal['stoploss'] - expected_sl) / entry)
    # if sl_diff > 0.001:  # Allow 0.1% tolerance
    #     print(f"[SL ADJUSTMENT] Signal SL {signal['stoploss']} adjusted to {expected_sl:.6f} (-2% from entry)")
    #     signal['stoploss'] = expected_sl

    # === DRY-RUN: FULL DETAILS ===
    if dry_run:
        print("\n" + "="*70)
        print("DRY-RUN TRADE SIMULATION")
        print("="*70)
        print(f"Symbol:       {symbol}")
        print(f"Direction:    {signal['direction']} ({side})")
        print(f"Leverage:     {leverage}x")
        print(f"Position Mode: {position_mode}")
        print(f"Order Type:   {order_type}")
        print(f"Entry:        {entry}")
        print(f"Quantity:     {qty:.6f}")
        print(f"Position $:   {usdt_amount * leverage:.2f} USDT")
        print(f"Take Profits: {signal['targets']}")
        print(f"TP Close %:   TP1={config['tp1_close_percent']}%, TP2={config['tp2_close_percent']}%, TP3={config['tp3_close_percent']}%, TP4={config['tp4_close_percent']}%")
        print(f"Stop Loss:    {signal['stoploss']}")
        if config.get('trail_sl_on_tp', 0) > 0:
            print(f"Trail SL:     Move to breakeven on TP{config['trail_sl_on_tp']}")
        rr = (signal['targets'][-1] - entry) / (entry - signal['stoploss'])
        print(f"Risk/Reward:  {rr:.2f}:1 (to final TP)")
        print("="*70 + "\n")
        return

    # === SET MARGIN MODE (Cross/Isolated) ===
    # First, set the margin type using the dedicated endpoint
    try:
        margin_resp = await bingx_api_request(
            'POST', '/openApi/swap/v2/trade/marginType',
            client['api_key'], client['secret_key'], client['base_url'],
            data={
                'symbol': symbol,
                'marginType': margin_type  # ISOLATED or CROSSED
            }
        )
        if margin_resp.get('code') == 0:
            print(f"✓ Margin mode set to {position_mode} (marginType: {margin_type})")
            await asyncio.sleep(0.5)  # Wait for margin mode to be applied
        else:
            print(f"⚠️  Margin mode setting failed: {margin_resp.get('msg')}")
            print(f"⚠️  Response: {margin_resp}")
    except Exception as e:
        print(f"⚠️  Margin mode setting error: {e}")
    
    # === SET LEVERAGE (with openType) ===
    try:
        leverage_resp = await bingx_api_request(
            'POST', '/openApi/swap/v2/trade/leverage',
            client['api_key'], client['secret_key'], client['base_url'],
            data={
                'symbol': symbol,
                'side': position_side,  # LONG or SHORT (not BUY/SELL)
                'leverage': leverage,
                'openType': open_type  # isolated or cross (lowercase)
            }
        )
        if leverage_resp.get('code') == 0:
            print(f"✓ Leverage set to {leverage}x with openType: {open_type}")
            await asyncio.sleep(0.5)  # Wait for leverage to be applied
        else:
            print(f"⚠️  Leverage setting failed: {leverage_resp.get('msg')}")
            print(f"⚠️  Response: {leverage_resp}")
    except Exception as e:
        print(f"⚠️  Leverage setting error: {e}")

    # === ENTRY ORDER ===
    entry_payload = {
        'symbol': symbol,
        'side': side,
        'positionSide': position_side,
        'type': order_type,
        'quantity': f"{qty:.6f}",
        'leverage': leverage,
        'openType': open_type  # Ensure margin mode is set on the order
    }
    
    # Add price for LIMIT orders
    if order_type == 'LIMIT':
        entry_payload['price'] = str(entry)
        entry_payload['timeInForce'] = 'GTC'
    
    print_payload("ENTRY ORDER", entry_payload)

    order = await bingx_api_request(
        'POST', '/openApi/swap/v2/trade/order',
        client['api_key'], client['secret_key'], client['base_url'],
        data=entry_payload
    )

    if order.get('code') != 0:
        print(f"ENTRY FAILED: {order.get('msg')}")
        return

    order_id = order.get('data', {}).get('order', {}).get('orderId')
    if not order_id:
        print("ENTRY: No orderId in response")
        return
    print(f"ENTRY SUCCESS: Order ID = {order_id}")
    
    # Wait a moment for the position to be created, then verify position mode
    await asyncio.sleep(1)
    try:
        pos_resp = await bingx_api_request(
            'GET', '/openApi/swap/v2/trade/position',
            client['api_key'], client['secret_key'], client['base_url'],
            params={'symbol': symbol}
        )
        if pos_resp.get('code') == 0 and pos_resp.get('data'):
            position_data = pos_resp['data'][0] if isinstance(pos_resp['data'], list) else pos_resp['data']
            actual_mode = position_data.get('marginType', 'unknown')
            # Check if margin mode matches expected
            expected_mode_lower = 'isolated' if margin_type == 'ISOLATED' else 'cross'
            if actual_mode.lower() == expected_mode_lower:
                print(f"✓ Position mode verified: {actual_mode.upper()}")
            else:
                print(f"❌ WARNING: Position opened as {actual_mode.upper()}, expected {position_mode}")
                print(f"   This may indicate the margin mode setting failed. Check your BingX account settings.")
                print(f"   Try manually setting margin mode to {position_mode} in BingX UI for {symbol}")
    except Exception as e:
        print(f"⚠️  Could not verify position mode: {e}")

    # === TAKE PROFIT ORDERS (configurable percentages) ===
    tp_percentages = [
        config.get('tp1_close_percent', 25.0),
        config.get('tp2_close_percent', 25.0),
        config.get('tp3_close_percent', 25.0),
        config.get('tp4_close_percent', 25.0)
    ]
    
    tp_orders = []  # Store TP order IDs for trail SL feature
    for i, tp in enumerate(signal['targets'][:4], 1):  # Ensure max 4 TPs
        tp_percent = tp_percentages[i-1] / 100.0  # Convert to decimal
        tp_qty = qty * tp_percent
        
        tp_payload = {
            'symbol': symbol,
            'side': opposite_side,
            'positionSide': position_side,
            'type': 'LIMIT',  # Use LIMIT orders for TP
            'quantity': f"{tp_qty:.6f}",
            'price': str(tp),  # Limit price for TP
            'timeInForce': 'GTC'
            # Note: reduceOnly is NOT used in Hedge mode (causes error)
            # The opposite side + positionSide combination ensures it closes the position
        }
        print_payload(f"TAKE PROFIT #{i} ({tp_percentages[i-1]}%)", tp_payload)

        tp_resp = await bingx_api_request(
            'POST', '/openApi/swap/v2/trade/order',
            client['api_key'], client['secret_key'], client['base_url'],
            data=tp_payload
        )
        if tp_resp.get('code') == 0:
            tp_id = tp_resp.get('data', {}).get('order', {}).get('orderId')
            tp_orders.append({'tp_level': i, 'order_id': tp_id, 'price': tp})
            print(f"TP #{i} SET ({tp_percentages[i-1]}%): ID = {tp_id}")
        else:
            print(f"TP #{i} FAILED: {tp_resp.get('msg')}")

    # === STOP LOSS ===
    sl_payload = {
        'symbol': symbol,
        'side': opposite_side,
        'positionSide': position_side,
        'type': 'STOP_MARKET',
        'quantity': f"{qty:.6f}",
        'stopPrice': signal['stoploss'],
        'workingType': 'MARK_PRICE'
        # Note: reduceOnly is NOT used in Hedge mode (causes error)
        # The opposite side + positionSide combination ensures it closes the position
    }
    print_payload("STOP LOSS", sl_payload)

    sl_resp = await bingx_api_request(
        'POST', '/openApi/swap/v2/trade/order',
        client['api_key'], client['secret_key'], client['base_url'],
        data=sl_payload
    )
    sl_id = None
    if sl_resp.get('code') == 0:
        sl_id = sl_resp.get('data', {}).get('order', {}).get('orderId')
        print(f"SL SET: ID = {sl_id}")
    else:
        print(f"SL FAILED: {sl_resp.get('msg')}")
        return  # Can't continue without SL
    
    # === TRAIL SL TO BREAKEVEN (if configured) ===
    trail_tp_level = config.get('trail_sl_on_tp', 0)
    if trail_tp_level > 0 and trail_tp_level <= len(signal['targets']) and len(tp_orders) > 0:
        print(f"\n✅ Trail SL feature enabled: Will move SL to breakeven when TP{trail_tp_level} is hit")
        print(f"   Current SL: {signal['stoploss']}, Breakeven: {entry}")
        # Start background monitoring task
        asyncio.create_task(monitor_tp_and_trail_sl(
            client, symbol, position_side, entry, qty, 
            tp_orders, sl_id, trail_tp_level, config
        ))

    # === MONITOR PnL (NO PARAMS CONFLICT) ===
    print("\nMonitoring position... (Ctrl+C to stop)")
    try:
        while True:
            await asyncio.sleep(10)
            pos = await bingx_api_request(
                'GET', '/openApi/swap/v2/trade/position',
                client['api_key'], client['secret_key'], client['base_url'],
                params={'symbol': symbol}  # ← Correct: uses params
            )
            if pos.get('data'):
                pnl = float(pos['data'][0]['unrealisedPnl'])
                print(f"Current PnL: {pnl:.4f} USDT")
    except KeyboardInterrupt:
        print("\nMonitoring stopped")
